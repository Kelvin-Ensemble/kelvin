<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts</h1>
<br/>

<div id="pcnav">
<table width=90%;>
    <tr>
        <td>
            <a href="<?php echo BASE_URL;?>concerts/past_concerts_2016-2020.php"><h3>2016 - 2017</h3></a>
        </td>
        <td>
          <a href="<?php echo BASE_URL;?>concerts/past_concerts_2011-2015.php"><h3>2015 - 2011</h3></a>
        </td>
        <td>
            <a href="<?php echo BASE_URL;?>concerts/past_concerts_2006-2010.php"><h3>2010 - 2006</h3></a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="<?php echo BASE_URL;?>concerts/past_concerts_2001-2005.php"><h3>2005 - 2001</h3></a>
        </td>
        <td>
          <a href="<?php echo BASE_URL;?>concerts/past_concerts_1996-2000.php"><h3>2000 - 1996</h3></a>
        </td>
        <td>
            <a href="<?php echo BASE_URL;?>concerts/past_concerts_1991-1995.php"><h3>1995 - 1991</h3></a>
        </td>
    </tr>
</table>
</div>

<?php include_once('footer.php'); ?>
