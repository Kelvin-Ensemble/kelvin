<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts from 2000 to 1996</h1>
<br/>

<ul>
  <div class="pctable">
    <table>
        <tr>
            <td><b>Autumn 2000</b><br/>
                Conductor: Michael Spencer<br/>
                <br/>
                Steve Arkell - Choreia<br/>
                Mac Yeats - The Anatomy of Air<br/>
                Schumann - Symphony No.3<br/>
            <br/><hr>
                Conductor: Julian Clayton<br/>
                <br/>
                Eric Chisolm – Piobaireachd Concerto<br/>
                Brahms – Symphony No. 2<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2000</b><br/>
                Conductor: Peter Jones<br/>
                <br/>
                Mendelssohn - Hebrides Overture<br/>
                Haydn - Horn Concerto No.1 (soloist: Fergust Kerr)<br/>
                Larsson - Pastoral Suite<br/>
                Beethoven - Symphony No.3<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1999</b><br/>
                Conductor: Garry Walker<br/>
                Saxophone: Brian Molley<br/>
                <br/>
                Stravinsky - Orpheus<br/>
                Michael Spencer - Las Redes de Piedra<br/>
                Mozart - Symphony No.39<br/>
                <br/><hr>
                Conductor: Susan Dingle<br/>
                Soloist: Nicola Boag<br/>
                <br/>
                Beethoven – Overture, Corolian Suite<br/>
                Dvorak – Romance for Violin<br/>
                Stravinsky – Suites for small Orchestra<br/>
                Holloway – Senerade in G<br/>
                Mozart – Symphony No. 29 in A Major K.201<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1999</b><br/>
                Conductor: William Conway<br/>
                <br/>
                Rachmaninov – Symphony No. 2<br/>
                Macmillan – Confessions of Isobel Goudie<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1998</b><br/>
                Conductor: David McDonald<br/>
                Saxophone: Sophie Askew<br/>
                <br/>
                Bach – Suite (overture) No. 4 in D<br/>
                Alwyn – Lyra Angelica Concerto for Harp and Strings<br/>
                Mozart – Divertimento in Eb K.166<br/>
                Tchaikovsky – Orchestral Suite No. 4 ‘Mozartina’<br/>
                <br/><hr>
                Conductor: Gary Walker<br/>
                <br/>
                Schubert – Symphony 5 in Bb<br/>
                Beethoven – Symphony 7 in A<br/>
                Schnittke – Mozart à la Haydn<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Summer 1998</b><br/>
                Conductor: Julian Clayton<br/>
                Soloist: Murray McLachlan<br/>
                <br/>
                Callum Kenmuir Concerto for Piano and Orchestra<br/>
                Rhapsody on Themes of Grieg<br/>
                <br/><hr>
                <b>Spring 1998</b><br/>
                Conductor: William Conway<br/>
                Soloist: Mhairi Milne<br/>
                <br/>
                Milhaud – ‘Le Boeuf sur le Toit’<br/>
                Lutoslawski – Danse Preludes<br/>
                Debussy – Premier Rhapsody<br/>
                Brahms – Symphony 1<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1997</b><br/>
                Conductor: William Conway<br/>
                <br/>
                Schnittke – Mozart à la Haydn<br/>
                Stravinsky – Concerto in Eb<br/>
                Strauss – Senerade in Eb<br/>
                <br/><hr>
                Conductor: Gary Walker<br/>
                <br/>
                Hallgrimsson Halfidi – Daydreams in Numbers (6 mvmts from Volumes 1 and 2)<br/>
                Harper – Chanson Minimale<br/>
                Schubert – unknown<br/>
                Haydn - unknown<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1997</b><br/>
                Conductor: William Conway<br/>
                Soloist: Donald Gillen<br/>
                <br/>
                ?!?!<br/>
                Mahler – Symphony 5<br/>
                Beethoven – Symphony 5<br/>
                Saint-Seans – First Cello Concerto<br/>
                Or<br/>
                Grieg – Holberg Suite<br/>
                Elgar – Senerade for Strings<br/>
                Britten – Simple Symphony<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1996</b><br/>
                Conductor: Nigel Boddice<br/>
                <br/>
                Debussy – Prelude à l’après-midi d’un faune<br/>
                Thomas Wilson – Pas de Quoi<br/>
                Beethoven – Symphony 5 in C Minor<br/>
                Britten – Peter and the Wolf. Narrated by either Richard Wilson/Ian Ainsworth<br/>
                <br/><hr>
                Conductor: Nigel Boddice<br/>
                <br/>
                Grieg – Halberg Suite<br/>
                Elgar – Senerade for Strings<br/>
                Britten – Simple Symphony<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1996</b><br/>
                Conductor: William Conway<br/>
                Soloist: Alison Dixon<br/>
                <br/>
                Beethoven – Symphony No. 6<br/>
                Sibelius – Violin Concerto<br/>
            </td>
        </tr>
    </table>
  </div>
</ul>

<?php include_once('footer.php'); ?>
