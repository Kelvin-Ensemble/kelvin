<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts from 1995 to 1991</h1>
<br/>

<ul>
  <div class="pctable">
    <table>
        <tr>
            <td><b>Autumn 1995</b><br/>
                Conductor: Nigel Boddice<br/>
                Soloist: Angela Whelan<br/>
                <br/>
                Faure - Masques et Bergamesques<br/>
                McGuire - Symphonies of Trains<br/>
                Haydn - Trumpet Concerto in Eb<br/>
                Mendelssohn - Symphony No.4 "Italian"<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1995</b><br/>
                Conductor: William Conway<br/>
                <br/>
                Mozart - Overture to the Marriage of Figaro<br/>
                Richard Strauss - Concerto for Oboe and Small Orchestra (soloist: Jane Emmanuel)<br/>
                Mendelssohn - Symphony No. 3 Scotch, Op 54<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1994</b><br/>
                Conductor:  Christopher Bell<br/>
                <br/>
                Haydn - Symphony No 83 in G minor, "La Poule"<br/>
                Mozart - Concerto for Clarinet (K 622) (soloist: Andrew Russell)<br/>
                Zoltan Kod&#225;ly - Marosszek Dances<br/>
                Peter Maxwell Davies - An Orkney Wedding, with Sunrise<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1994</b><br/>
                Conductor: John Lubbock<br/>
                <br/>
                Mendelssohn - Hebrides Overture, ("Fingals Cave")<br/>
                Mahler (arr Schoenberg) - Lieder eines fahrenden Gesellen (soloist: Christine Cairns, mezzo-soprano)<br/>
                Beethoven - Symphony No. 3 in E Flat ("Eroica")<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 1993</b><br/>
                Conductor:  William Conway<br/>
                <br/>
                Edward Harper - The Fiddler of the Reels<br/>
                Mozart - Sinfonia Concertante in Eb for Violin and Viola, K.364 (soloists: Sharon Moir and Yvonne Jarrett)<br/>
                Richard Wagner - Siegfried Idyll<br/>
                Beethoven - Symphony No 1 in C, Opus 21<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 1993</b><br/>
                Conductor:  Richard Honner<br/>
                <br/>
                Tchaikovsky - Suite No 1 in D minor, Op 43<br/>
                Richard Strauss - Metamorphosen<br/>
            </td>
        </tr>

        <tr>
            <td><b>Autumn 1992</b><br/>
                Concert with Edinburgh University Chamber Orchestra<br/>
                Conductor:  William Conway<br/>
                <br/>
                Rossini - Barber of Seville Overture<br/>
                Benjamin Britten - Lachrymae, Op 48a (soloist: Carolyn Sparey-Gillies)<br/>
                Beethoven - Symphony No 7 in A major Op 92<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td><b>Autumn 1991</b><br/>
                Conductor:  Paul Middleton<br/>
                <br/>
                Tchaikovsky - Serenade for Strings<br/>
                Mozart - Flute Concerto in D Major (soloist: Camille Mason)<br/>
                Vivaldi - 'Winter' from the Four Seasons (soloist: Edward Doyle)<br/>
                Haydn - Symphony No. 44<br/>
            </td>
            <td></td>
        </tr>
    </table>
  </div>
</ul>

<?php include_once('footer.php'); ?>
