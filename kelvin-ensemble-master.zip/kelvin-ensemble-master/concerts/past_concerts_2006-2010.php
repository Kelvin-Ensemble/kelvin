<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts from 2010 to 2006</h1>
<br/>

<ul>
  <div class="pctable">
    <table>
        <tr>
            <td><b>Autumn 2010</b><br/>
                Conductor: Tommy Fowler<br/>
                <br/>
                Humperdinck - Prelude from "Hansel and Gretel"<br/>
                Saint-Saens - Danse Macabre<br/>
                Ravel - Mother Goose<br/>
                Prokofiev - "Troika" from "Lieutenant Kije"<br/>
                Delius - Sleigh Ride<br/>
                Tchaikovsky - The Nutcracker Suite<br/>
            </td>
            <td></td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2010</b><br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Pre-concert talk by Howard Blake with a first performance of "Speiltrieb", performed by the Edinburgh Quartet<br/>
                John Adams - Lollapalooza<br/>
                Howard Blake - Diversions: Concerto for Marimba and Orchestra (Soloist:Heather Corbett)<br/>
                Prokofiev - Symphony No.5<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2009</b><br/>
                Conductor: Gareth John<br/>
                <br/>
                Shostakovich - Festive Overture<br/>
                Borodin - Polovtsian Dances<br/>
                Borodin - Steppes in Central Asia<br/>
                Mussorgsky (orch. Ravel) - Pictures at an Exhibition<br/>
            </td>
            <td></td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2009</b><br/>
                Conductor: Justin Fung<br/>
                <br/>
                Mark Davis - Beginnings<br/>
                Prokofiev - Romeo and Juliet Suite<br/>
                Tchaikovsky - Symphony No.4<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2008</b><br/>
                <br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Bernstein - Symphonic Dances from West Side Story<br/>
                Shore - Lord of the Rings<br/>
                Blake - The Snowman (with Juliet Cadzow)<br/>
                Williams - ET Main Theme<br/>
                Williams - Jurassic Park<br/>
                Williams - Harry Potter<br/>
                orch. Willcocks - Five Christmas Carols<br/>
                Anderson - Sleigh Ride<br/>
                <br/><hr>
                Conductor: Gareth John<br/>
                <br/>
                Copland - Fanfare for the Common Man<br/>
                Copland - Hoe Down from Rodeo<br/>
                Gershwin - Rhapsody in Blue (soloist Jennifer MacRitchie<br/>
                Dvorak - New World Symphony<br/>
            <td></td>
            </td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2008</b><br/>
                Conductor: Kenneth Woods<br/>
                <br/>
                Wagner - Overture to Rienzi<br/>
                Bloch - Schelmo (soloist Barbara Misiewicz)<br/>
                Sibelius - Symphony No.2<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2007</b><br/>
                <br/>
                Glasgow University Choral Society Concert<br/>
                Conductor: Marjory Rycroft<br/>
                <br/>
                Haydn - The Creation<br/>
                <br/><hr>
                Conductor: Gareth John<br/>
                <br/>
                Elgar - Introduction and Allegro for String Quartet and String Orchestra<br/>
                Strauss - Suite for 13 Winds in B flat major<br/>
                Vaughan Williams - Fantasia on a theme by Thomas Tallis<br/>
                Haydn - Symphony No.104 in D Major<br/>
            </td>
            <td></td>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2007</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Gordon Munro<br/>
                <br/>
                Sibelius - Finlandia<br/>
                Sibelius - The Captive Queen<br/>
                Elgar - Te Deum & Benedictus<br/>
                Schubert - Mass No.5 in Ab<br/>
                <br/><hr>
                Concert with Edinburgh University Chamber Orchestra Chamber Orchestra
                Conductor: William Conway<br/>
                <br/>
                Martin Suckling - Mosaic<br/>
                Elgar - Sea Pictures (soloist: Susan Boyd)<br/>
                Stravinsky - The Rite of Spring<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2006</b><br/>
                Conductor: Kenneth Woods<br/>
                <br/>
                Tommy Fowler - 15th Anniversary Commission<br/>
                Walton - Viola Concerto (soloist: Veronika Toth)<br/>
                Dvorak - Symphony No. 8<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2006</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Myra Soutar<br/>
                <br/>
                Verdi - Stabat Mater (from "Four Sacred Pieces")<br/>
                Brahms - A German Requiem<br/>
                <br/><hr>
                Mozart 250th Anniversary Concert<br/>
                Conductor: Marjory Rycroft<br/>
                <br/>
                Mozart - Church Sonata No.12 in C<br/>
                Mozart - Church Sonata No.14 in C<br/>
                Mozart - Mass in C minor<br/>
                <br/><hr>
                Conductor: John Moore<br/>
                <br/>
                Beethoven - Egmont Overture<br/>
                Grieg - Piano Concerto in A minor (piano: Jennifer MacRitchie)<br/>
                Tchaikovsky - Symphony No.5 in E minor<br/>
            </td>
        </tr>
    </table>
  </div>
</ul>

    <?php include_once('footer.php'); ?>
