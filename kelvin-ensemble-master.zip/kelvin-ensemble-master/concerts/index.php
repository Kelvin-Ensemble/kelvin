<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Concerts</title>

<!--<img src="../images/poster_2016_spring.png" alt="Coming Soon" style="float:right; padding-left:15px; margin-right:20px;" height="600px"/>-->

<h1>Upcoming Concerts</h1>

<br/>

<h3>Autumn 2017</h3>
<p>Conductor: John Grant</br>
	More details coming soon
</p>

<!--
<p>The repertoire for this tour is:</p>
<ul>
<li>Mendelssohn - Hebrides Overture</li>
<li>Schubert - Symphony No.8</li>
<li>Rossini - Barber of Seville Overture</li>
<li>Beethoven - Symphony No.6</li>
</ul>

<p>Conductor: John Grant</p>
<br/>

<h3>Sabhal Mòr Ostaig - Skye</h3>

<p>The concert begins at <b>7:30pm</b> on the <b>1st of June</b>.</p>

<p>We will be playing at Sabhal Mòr Ostaig. <br/>Directions found <a href="https://www.google.co.uk/maps/place/Sabhal+M%C3%B2r+Ostaig/@57.086897,-5.871878,15z/data=!4m5!3m4!1s0x0:0xc4c911aa8c2544f1!8m2!3d57.086897!4d-5.871878">here</a>.<br/>
	Please reserve tickets <a href="http://www.seall.co.uk/events/kelvin-ensemble-1-jun/">here.</a> We unfortunately cannot guarantee entry on the door without a reservation.</br>
	Ticket prices are: Adults £12 / Students £10 / Young people £6 / Members £10 / Under 10s and Seasons free.</p>

</br>

<div class='white_box'>
	<h3><u>Buying Tickets for the Glasgow concert</u></h3>
-->
	<!--<p>Tickets will be available soon!</p>-->

<!--
	<p>Tickets are available to buy online in advance, which can be picked up at the door on the night of the concert. We don't send an e-ticket, and will have a list of all the people who have purchased tickets on the door.
		The confirmation email from PayPal often ends up redirecting to spam, but email us if you are at all worried. It will also be possible to buy tickets on the door.</p>

	<h4>General Admission &#163;10</h4>

		<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="WM2TC268LMUBQ">
			<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
		</form>

	<h4>Concession Tickets &#163;5 - (Under 18s, Students, Seniors)</h4>

		<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="4FDVL8DX78H4U">
			<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
		</form>

	</br>

		<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" >
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIG5QYJKoZIhvcNAQcEoIIG1jCCBtICAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCFWp4DpMw9zRlIF4pBTIkoamNi2cAGgO+AoKVnBURpHkCpl7OP9dbRUFk9Ec4+KXwIN+f62+eaYufCfmJ7jS68YxDCNlclvbTXk0L6TOM42Q9GX4yZXG6GUF81LjTy/47y4NtnJ1EfGYHjSqLgghEQzq7X4nOtv+S5bvYQx3MeUTELMAkGBSsOAwIaBQAwYwYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAiePvMy2UwoOYBAXuws3YaVxVBr1CMq072klLyxy/06Tzbi1A5D7DaNn+lafXhhHZ/nwNuXZafnF2TbOn7fme4ZK+qF9YSLy2pTX6CCA4cwggODMIIC7KADAgECAgEAMA0GCSqGSIb3DQEBBQUAMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDAyMTMxMDEzMTVaFw0zNTAyMTMxMDEzMTVaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwUdO3fxEzEtcnI7ZKZL412XvZPugoni7i7D7prCe0AtaHTc97CYgm7NsAtJyxNLixmhLV8pyIEaiHXWAh8fPKW+R017+EmXrr9EaquPmsVvTywAAE1PMNOKqo2kl4Gxiz9zZqIajOm1fZGWcGS0f5JQ2kBqNbvbg2/Za+GJ/qwUCAwEAAaOB7jCB6zAdBgNVHQ4EFgQUlp98u8ZvF71ZP1LXChvsENZklGswgbsGA1UdIwSBszCBsIAUlp98u8ZvF71ZP1LXChvsENZklGuhgZSkgZEwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tggEAMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAgV86VpqAWuXvX6Oro4qJ1tYVIT5DgWpE692Ag422H7yRIr/9j/iKG4Thia/Oflx4TdL+IFJBAyPK9v6zZNZtBgPBynXb048hsP16l2vi0k5Q2JKiPDsEfBhGI+HnxLXEaUWAcVfCsQFvd2A1sxRr67ip5y2wwBelUecP3AjJ+YcxggGaMIIBlgIBATCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE3MDUwODE1MDA0N1owIwYJKoZIhvcNAQkEMRYEFDr0pUKFAAOeM7TtfuUL9BQr9bfXMA0GCSqGSIb3DQEBAQUABIGAKXrdPbOzL/73PSc03waMAtLoFTvOko8Rrsr24/HOcdCb1disYu1eCyGovB16C0zDMRrayxYSLs6BjmMJU1a/0swYKZMMVdHjPaoUHI9DeN6OlApLzBweHWb+1sj3c40Z0oNWDJ6IYSNppLxUX2vLzhIZIXOqDLKPSgxFnQCZF/Q=-----END PKCS7-----
			">
			<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_viewcart_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
		</form>

-->


	<!--<p> You can no longer buy tickets online, but they will be available on the door. <br/>
	Prices for General Admission is &#163;10 and for Under 18s, Students and Seniors, they cost &#163;5.
</p>-->

</div>


<br/>
<p>
	For information on concerts, or for other information, please contact <a href="mailto:treasurer&#64;kelvin-ensemble.co.uk">treasurer&#64;kelvin-ensemble.co.uk</a><br/>
</p>

<br/>

<?php include_once('footer.php'); ?>
