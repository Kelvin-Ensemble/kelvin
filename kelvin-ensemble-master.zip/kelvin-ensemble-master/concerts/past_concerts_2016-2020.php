<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts since 2015</h1>
<br/>

<ul>
  <div class="pctable">
    <table>

      <tr>
          <td><b>Summer 2017 Tour</b><br/>
              Conductor: John Grant<br/>
              Kelvin Chamber Orchestra<br/>
              <br/>
              Mendelssohn - Hebrides Overture<br/>
              Schubert - Symphony No.8<br/>
              Rossini - Barber of Seville Overture<br/>
              Beethoven - Symphony No.6<br/>
          </td>
          <td></td>
      </tr>
      <tr>
          <td colspan=2><hr></td>
      </tr>
        <tr>
          <td></td>
          <td><b>Spring 2017</b><br/>
              Conductor: John Grant<br/>
              <br/>
              Glazunov – Symphony No. 5<br/>
              Tchaikovsky – Swan Lake<br/>
              Tchaikovsky – 1812 Overture<br/>
          </td>
        </tr>
        <tr>
            <td><b>Autumn 2016</b><br/>
                Conductor: John Grant<br/>
                <br/>
                Danzon No. 2 - Marquez<br/>
                Escapades - John Williams<br/>
                Excerpts from Romeo &amp; Juliet - Prokofiev<br/>
                Music from 'Up' - Giacchino<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2016</b><br/>
                Conductor: Chris Gray<br/>
                <br/>
                44th Symphony - Haydn<br/>
                Romeo &amp; Juliet Fantasy Overture - Tchaikovsky<br/>
                West Side Story Symphonic Dances - Bernstein<br/>
            </td>
        </tr>
    </table>
  </div>
</ul>

<?php include_once('footer.php'); ?>
