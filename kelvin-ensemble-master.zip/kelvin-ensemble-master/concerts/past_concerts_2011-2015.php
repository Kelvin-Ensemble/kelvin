<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts from 2015 to 2011</h1>
<br/>

<ul>
  <div class="pctable">
    <table>
      <tr>
          <td><b>Autumn 2015</b><br/>
              Conductor: Chris Gray<br/>
              <br/>
              Bedřich Smetana - Má Vlast<br/>
          </td>
          <td></td>
      </tr>

      <tr>
          <td colspan=2><hr></td>
      </tr>
        <tr>
            <td></td>
            <td><b>Spring 2015</b><br/>
            Conductor: Chris Gray<br/>
            <br/>
            Gershwin - Girl Crazy<br/>
            Gershwin - Rhapsody in Blue (soloist: Nick Lauener)<br/>
            Shostakovich - Suite for Variety Orchestra<br/>
            </td>
        </tr>

        <tr>
            <td><b>Autumn 2014</b><br/>
                Conductor: Chris Gray<br/>
                <br/>
                Puccini - Preludio Sinfonico<br/>
                Grieg - Norwegian Dances<br/>
                Borodin - Symphony 2<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2014</b><br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Suppe - Light Cavalry Overture<br/>
                Saint-Sa&#235;ns - Piano concerto No.2<br/>
                Tchaikovsky - Symphony No. 2<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2013</b><br/>
                Conductor: Kevin Price<br/>
                <br/>
                Johannes Brahms - Academic Festival Overture<br/>
                Richard Wagner - Wesendonck Lieder (soloist: Jemma Brown)<br/>
                Anton&#237;n Dvor&#225;k - New World Symphony<br/>
            </td>
            <td></td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2013</b><br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Copland - Our Town<br/>
                Dvor&#225;k - American Suite (Op.98b)<br/>
                Charles Ives - Symphony No. 2<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2012</b><br/>
                Conductor: Oliver Rundell<br/>
                <br/>
                Vaughan Williams - The Wasps<br/>
                Elgar - Cello Concerto in E Minor (soloist: David Sloan)<br/>
                Brahms - Symphony No. 2 in D Major<br/>
            </td>
            <td></td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2012</b><br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Sibelius - Finlandia<br/>
                Nielsen - Seven Dances from Aladdin<br/>
                Sibelius - Symphony No.2<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2011</b><br/>
                Conductor: Oliver Rundell<br/>
                <br/>
                MacCunn - Land of the Mountain and the Flood<br/>
                Mendelssohn - Hebrides Overture, ("Fingals Cave")<br/>
                Arnold - Tam O'Shanter Overture<br/>
                Mendelssohn - Symphony No.3, ("The Scottish Symphony")<br/>
            </td>
            <td></td>
        </tr>


        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2011</b><br/>
                Conductor: Chris Swaffer<br/>
                <br/>
                Stravinsky - Greeting Prelude<br/>
                Tchaikovsky - Violin Concerto (Soloist: Tamas Fejes)<br/>
                Holst - The Planets Suite (Guest group: The Madrigirls)<br/>
            </td>
        </tr>
    </table>
  </div>
</ul>

<?php include_once('footer.php'); ?>
