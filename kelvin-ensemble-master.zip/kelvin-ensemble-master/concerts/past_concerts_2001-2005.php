<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Past Concerts</title>

<h1>Past Concerts from 2005 to 2001</h1>
<br/>

<ul>
  <div class="pctable">
    <table>
        <tr>
            <td><b>Autumn 2005</b><br/>
                Conductor: James Grossmith<br/>
                <br/>
                Dohnanyi - Szeged Mass (Scottish Premiere)<br/>
                Vaughan Williams - Job, A Masque for Dancing<br/>
            </td>
            <td></td>
        </tr>
        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2005</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: <br/>
                <br/>
                Dvorak - Te Deum<br/>
                Jean Sharrock - Gloria<br/>
                Mozart - Requiem<br/>
                <br/><hr>
                Glasgow University Music Club 50th Anniversary<br/>
                Conductor: Marjory Rycroft<br/>
                <br/>
                Haydn - Symphony No.100 "Military"<br/>
                <br/><hr>
                Concert with Edinburgh University Chamber Orchestra Chamber Orchestra<br/>
                Conductor: William Conway<br/>
                <br/>
                Stravinsky - Symphonies of Winds<br/>
                Glasunov - Saxophone Concerto (saxophone - Andrew Somerville<br/>
                Berlioz - Symphonie Fantastique<br/>
            </td>
        </tr>

        <tr>
            <td><b>Autumn 2004</b><br/>
                Conductor: Bashar Lulua<br/>
                <br/>
                Matthew Taylor - The Needles Overture (Scottish Premiere)<br/>
                Mozart - Sinfonia Concertante in E flat for Violin and Viola (Violin - Feargus Hetherington, Viola - Alexa Beattie<br/>
                Brahms - Symphony No.2<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2004</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Myra Soutar<br/>
                <br/>
                Haydn - 'Spring' from The Seasons<br/>
                Schubert - Mass No.1 in F major<br/>
                Faure - Requiem (movements IV-VII)<br/>
                <br/><hr>
                Conductor: Mark Evans<br/>
                <br/>
                Smetana - Vltava<br/>
                Ibert - Flute Concerto (soloist: Emma Wilkins)<br/>
                Ciurlionis - In The Forest (Scottish Premiere)<br/>
                Bizet - Selection of Movements from L'Arlesienne Suites 1&2<br/>
            </td>
        </tr>
        <tr>
            <td><b>Autumn 2003</b><br/>
                Conductor: Marco Romano<br/>
                <br/>
                Beethoven - Coriolan Overture<br/>
                Mozart - Piano Concerto no.21 in C (soloist Natalia Ossentchakova)<br/>
                Delius - On Hearing the First Cuckoo in Spring, Summer Night on the River<br/>
                Beethoven - Symphony No.8<br/>
                <br/><hr>
                Conductor: Mark Evans<br/>
                <br/>
                Arvo Part – Silouans Song<br/>
                Stravinsky – Pulcinella Suite<br/>
                Shostakovich  - Chamber Symphony (op.110a arr. Rudolf Barshai [‘79])<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2003</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Myra Soutar<br/>
                <br/>
                Mozart - Mass in C Minor<br/>
                Shostakovich - Festival Overture<br/>
                Walton - Coronation Te Deum (Organ and Choir only)<br/>
                Vaughan Williams - Towards the Unknown Region<br/>
                <br/><hr>
                Concert with Edinburgh University Chamber Orchestra Chamber Orchestra<br/>
                Conductor: William Conway<br/>
                <br/>
                Reich - Variations for Strings, Winds and Keyboards<br/>
                Tchaikovsky - Violin Concerto (soloist - Feargus Hetherington)<br/>
                Mussorgsky (orch. Ravel) - Pictures at an Exhibition<br/>
            </td>
        </tr>

        <tr>
            <td><b>Autumn 2002</b><br/>
                <br/>
                Concert with the Glasgow University Choral Society<br/>
                Conductor: Giles Brightwell<br/>
                <br/>
                Handel - Messiah<br/>
                <br/><hr>
                Conductor: Stephen Broad<br/>
                <br/>
                McGuire - The Caledonian Muse: A Symphonic Rhapsody<br/>
                MacCunn - Land of the Mountain and the Flood<br/>
                Mendelssohn - Symphony No.3<br/>
                <br/><hr>
                Concert with Edinburgh University Chamber Orchestra Chamber Orchestra<br/>
                Conductor: Robert Dick<br/>
                <br/>
                Mozart - Marraige of Figaro Overture<br/>
                Weber - Clarinet Concerto No.2<br/>
                Schubert - Symphony No.4</b>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2002</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Myra Soutar<br/>
                <br/>
                Tippett - Spirituals from Child of our Time<br/>
                Rossini - Stabat Mater<br/>
                Saint-Saens - Finale of Symphony No.3 "Organ"<br/>
                <br/><hr>
                Conductor: Will Conway<br/>
                Piano: Simon Smith<br/>
                <br/>
                Kodaly - Dances of Galanta<br/>
                MacMillan - "... in angustiis I" (world premier)<br/>
                MacMillan - Cumnock Fair<br/>
                Beethoven - Symphony No.5<br/>
                <br/><hr>
                Conductor: Stephen Broad<br/>
                <br/>
                Petr Eben - Two Invocations for Trombone and Organ (Trombone: Gavin Bryce, Organ: Jonathan Salmond)<br/>
                Giles Swayne - Symphony for Small Orchestra<br/>
            </td>
        </tr>

        <tr>
            <td><b>Autumn 2001</b><br/>
                Conductor: Giles Brightwell<br/>
                <br/>
                Beethoven - Egmont Oveture<br/>
                Copland - Clarinet Concerto<br/>
                Mozart - Requiem<br/>
            </td>
            <td></td>
        </tr>

        <tr>
            <td colspan=2><hr></td>
        </tr>

        <tr>
            <td></td>
            <td><b>Spring 2001</b><br/>
                <br/>
                Thomas Coates Memorial Concert<br/>
                Conductor: Myra Soutar<br/>
                <br/>
                Verdi - Reqiuem<br/>
                <br/><hr>
                Conductor: William Conway<br/>
                <br/>
                Debussy - La Mer<br/>
                Shostakovich - Symphony No.5<br/>
            </td>
        </tr>
    </table>
  </div>
</ul>

<?php include_once('footer.php'); ?>
