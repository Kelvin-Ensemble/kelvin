<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title> Support Us</title>

<h1>Friends of the Ensemble</h1>
<p>
The Kelvin Ensemble was founded as a chamber orchestra in 1991 by a group of enterprising students. It as since grown into a full-scale symphony orchestra. By becoming a Friend of the Kelvin Ensemble you can help us to continue and expand our much-loved institution, which provides fantastic opportunities for young people at Glasgow University.
</p>
<p>
We offer several different support packages, starting from just £20 per season (September-September).
</p>
<ul>
<div class='white_box'>
<table width=900>
	<tr>
		<td style="padding:10px"><b><font color="DarkGreen"> Friends &#163;20-49</font></b><br/>
			<ul>
			<li>Two discounted tickets to all concerts</li>
			<li>Priority seating</li>
			<li>Named acknowledgement in both concert programmes</li>
			</ul>
		</td>
		<td style="padding:10px"><b><font color="mediumblue">Maestro Friends &#163;50-99</font></b><br/>
			<ul>
			<li>Four discounted tickets to all concerts</li>
			<li>Priority seating</li>
			<li>Named acknowledgement in concert programmes</li>
			</ul>
		</td>
	</tr>

	<tr>
		<td style="padding:10px"><font color="red"> <b>Patron &#163;100+</font></b><br/>
			<ul>
			<li>Four free tickets</li>
			<li>A further two discounted tickets</li>
			<li>Priority seating</li>
			<li>Named acknowledgement in concert programmes</li>
			</ul>
		</td>
		<td style="padding:10px"><b><font color="black">Corporate Sponsorship</font></b><br/>
			<ul>
			<li>Logo and link on our website</li>
			<li>Full page advertisement in both concert programmes</li>
			<li>Logos on all posters and other promotional material</li>
			<li>15 minute talk or video at our annual ball</li>
			<li>Free tickets for up to four people</li>
			<li>Priority seating</li>
			</ul>
		</td>
	</tr>
</table>

<br/>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<b>&nbsp;&nbsp;&nbsp;Become a Friend of the Kelvin Ensemble today!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="V7SJS5JAKUYZL">
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal � The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</div>
</ul>
<br/>

<br/>

<p>
	For more information about Friends, Corporate, or other sponsorship opportunities, please contact us at <a href="mailto:chairperson&#64;kelvin-ensemble.co.uk">chairperson&#64;kelvin-ensemble.co.uk</a> or <a href="mailto:fundraising@kelvin-ensemble.co.uk">fundraising@kelvin-ensemble.co.uk</a>.
</p>

<br/><br/>
<h3>Current Friends</h3>

<div id="friends">
<table width="80%">
  <tr>
    <td>
			<h4>Chris Swaffer</h4>
		</td>
		<td>
			<h4>Mr and Mrs Smith</h4>
		</td>
	</tr>
	<tr>
		<td>
			<h4>The Violin Shop</h4>
		</td>
		<td>
			<h4>Coopers</h4>
		</td>
	</tr>
</table>

<br/><br/>

<center>
	<a href="https://www.studypool.com"><img src="../images/studypool.png" width="150px"/></a>
	<br/><br/>
	"Kelvin Ensemble is sponsored by Studypool, a leader in online homework help"
</center>

</div>


<?php include_once('footer.php'); ?>
