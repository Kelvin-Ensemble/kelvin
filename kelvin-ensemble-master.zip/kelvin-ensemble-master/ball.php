<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>The Kelvin Ball</title>

<h4>Kelvin Ball</h4><br/>
<p>
Venue: GUU<br/>
Date: 21/3/15<br/>
Attire: Formal<br/>
Time: 7.00pm<br/>
Details: 3 course dinner followed by a ceilidh
</p><br/>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="WVHEN7KPWJSCE">
  <table>
    <tr><td><input type="hidden" name="on0" value="Ticket Type">Ticket Type</td></tr><tr><td><select name="os0">
      <option value="Ball and Ceilidh">Ball and Ceilidh £30.00 GBP</option>
      <option value="Ceilidh only">Ceilidh only £6.00 GBP</option>
    </select> </td></tr>
  </table><br/>
  <input type="hidden" name="currency_code" value="GBP">
  <input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online.">
  <img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>

<?php include_once('footer.php');?>
