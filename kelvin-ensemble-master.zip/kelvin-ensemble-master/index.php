<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>The Kelvin Ensemble</title>

<body>
<p>
The Kelvin Ensemble is a student run symphony orchestra performing works chosen by the student committee throughout the year.
"Kelvin" performs two concerts a year within the university area, providing students with the chance to both perform and socialise within a thriving music scene.
Members are expected to play to a high level and display the musicianship and dedication typical of a full symphony orchestra.
<br/><br/>
</p>



<h2>Open Rehearsal and Auditions</h2>
<p>
  Kelvin Ensemble is holding an Open Rehearsal on the <b>16th of September</b> starting at <b>14.00</b>. Anyone is free to come along and meet us all and get a feel for the orchestra.<br/>
  Audition slots are live, with String Auditions held on the 23rd and 30th of September, and the 1st of October. Brass and Woodwind will be on the 24th, 26th, and 30th of September. Percussion and piano will also be on the 26th of September.<br/>
  If you can't make any of the available dates please contact <a href="mailto:stringmanager&#64;kelvin-ensemble.co.uk">String manager</a> or <a href="mailto:bwp&#64;kelvin-ensemble.co.uk">BWP manager</a> to see if we can arrange another time.<br/>
  <br/>
  <b>To book an audition time, head over to the <a href="/contact_us/join.php">Join</a> page for information and the booking page.</b>
</p>
<br/>

<!--
<h2>Kelvin Chamber Orchestra Tour</h2>
<p>
  We are touring the Scottish highlands, performing in Skye and Inverness before returning to Glasgow for a final concert.
  <br/>
  <br/>

  The program will be:<br/><br/>
  Mendelssohn - Hebrides Overture<br/>
  Schubert - Symphony No.8<br/>
  Rossini - Barber of Seville Overture<br/>
  Beethoven - Symphony No.6</br>

  <br/>
  Please see the <a href="./concerts/">Concerts</a> page for more information!<br/><br/>
  </p>


<h2>Concert - 11th of March 2017</h2>
<p>
  Our spring concert took place in Bute Hall, on the 11th of March (directions found <a href="https://www.google.co.uk/maps/place/University+of+Glasgow/@55.8720331,-4.2897026,17.33z/data=!4m5!3m4!1s0x488845d20af469b3:0xa3f0620b655e4983!8m2!3d55.8721211!4d-4.2882005">here</a>).
<br/>
<br/>

The program for this concert was:<br/><br/>
Glazunov – Symphony No. 5<br/>
Tchaikovsky – Swan Lake<br/>
Tchaikovsky – 1812 Overture<br/>

<br/>
Please see the <a href="./concerts/">Concerts</a> page for more information<br/><br/>
</p>

<p>Information on auditions coming soon<br/><br/></p>
-->

<img src="about/gallery/15.jpg" alt="no photo :(" width="1024" height="325">
<br/>

<!--
<h2>Concerto Competition</h2>

<p>
  Applications for the Concerto Competition are now open! Find out more <a href="<?php echo BASE_URL;?>contact_us/concerto_apply.php">here</a>.
</p>
<br/>
-->

<!--
<p>
  Applications for the Concerto Competition have now closed.
  You are welcome to come and see the competition on the 23rd of January from 2pm until 5pm in the Glasgow University Concert Hall.
  This event is open to the public, free entry, informal with refreshments available.
</p>
<br/>

-->


<h2>Supporting the Orchestra</h2>
<p>
  Now there is an easier way than ever to support the orchestra! As well as becoming a friend or corporate sponsor, it is now possible to raise money for the orchestra at <a href="http://www.easyfundraising.org.uk/causes/kelvinensemble/" target="_new">Easy Fundraising</a>.
</p>
<p>All you have to do is register and up to 50% of your personal shopping at several major retailers will be donated to the Kelvin Ensemble at no extra cost to you!</p>
<br/>
<br/>

<!--
<h2>The Kelvin 2015 Ball</h2>
<p>
  You can buy tickets for the Kelvin Ball or just the ceilidh afterwards <a href="<?php echo BASE_URL;?>ball.php">here</a>. It will take place on the 21st of March.
</p>
<br/><br/>
-->

<!-- Facebook -->

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>

<div id="social_media">
<table  style="width:100%" align="centre">
<tr>
<td class="social_table">
  <div class="fb-like-box" data-href="https://www.facebook.com/kelvinensemble" data-width="500" data-height="400" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="true" data-show-border="false"></div>
</td>

<!-- Twitter -->
<td class="social_table">
<a class="twitter-timeline" href="https://twitter.com/kelvinensemble" data-widget-id="539182557506859008">Tweets by @kelvinensemble</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
</script>
</td>
</tr>
</table>
</div>


<!-- Begin MailChimp Signup Form -->
<link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
<style type="text/css">
	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; }
	/* Add your own MailChimp form style overrides in your site stylesheet or in this style block.
	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
</style>
<div id="mc_embed_signup">
<form action="//kelvin-ensemble.us12.list-manage.com/subscribe/post?u=55579d3d3daeb1df9a81a5c19&amp;id=d5e00d1187" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll">
	<h2>Subscribe to the Kelvin Ensemble Mailing List</h2>
<div class="indicates-required"><span class="asterisk">*</span> indicates required</div>
<div class="mc-field-group">
	<label for="mce-EMAIL">Email Address  <span class="asterisk">*</span>
</label>
	<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
</div>
<div class="mc-field-group">
	<label for="mce-FNAME">First Name </label>
	<input type="text" value="" name="FNAME" class="" id="mce-FNAME">
</div>
<div class="mc-field-group">
	<label for="mce-LNAME">Last Name </label>
	<input type="text" value="" name="LNAME" class="" id="mce-LNAME">
</div>
	<div id="mce-responses" class="clear">
		<div class="response" id="mce-error-response" style="display:none"></div>
		<div class="response" id="mce-success-response" style="display:none"></div>
	</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_55579d3d3daeb1df9a81a5c19_d5e00d1187" tabindex="-1" value=""></div>
    <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
    </div>
</form>
</div>
<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
<!--End mc_embed_signup-->

<?php include_once('footer.php'); ?>
