<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Members</title>

<h1>Members' Area</h1>
<p>
  We have regular rehearsals on Tuesday evenings in the Concert Hall, and often additional rehearsals in the weekends approaching the concerts.
</p>

<!--
<h1>Auditions and Open Rehearsal</h1>
<p>
	There will be an open rehearsal on 19 Sept in the Concert Hall from 2:30-4:30pm.
<p>
	Auditions will be on 26th &amp; 27th of September (Strings), 29th of September (Mixed, with preference for Percussion), and 3rd &amp; 4th of October (Brass/Woodwinds).
</p>
<p>
  To book an audition time, head over to the <a href="../contact_us/join.php">Join</a> page for information and the booking page.
</p>

<br/>
-->
<br/>


<p>
  For those interested in joining the ensemble, please <a href="../contact_us/">email us</a> to find out more.  We hold auditions in mid to late September, coinciding with the start of the academic year, however we do occasionally need extra players so it's always worth letting us know if you are interested.
</p>


<h2>Calendar</h2>
<p>
Rehearsals and other events will be added to the calendar below as they are scheduled.  If this information looks incomplete, please <a href="../contact/">email</a> either the Brass/Wind/Percussion manager or the Strings manager.
</p><br/>

<iframe src="https://calendar.google.com/calendar/embed?src=webmaster%40kelvin-ensemble.co.uk&ctz=Europe/London" style=" border-width:0 " width="600" height="500" frameborder="0" scrolling="no"></iframe>

<br/><br/><p>Committee members can log in to <a href="http://www.google.com/calendar/hosted/kelvin-ensemble.co.uk/render">edit the calendar</a> or access the committee email (for information on how to do this, please contact  <a href="mailto:webmaster&#64;kelvin-ensemble.co.uk">webmaster@kelvin-ensemble.co.uk</a>.</p>

<br/><br/>
<p>The Kelvin Ensemble's Constitution can be downloaded <a href="KelvinConstitution2017.pdf">here</a>.</p>

<?php include_once('footer.php'); ?>
