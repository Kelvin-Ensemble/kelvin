<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<h1>Gallery</h1>
<p>
A few photographs of the Ensemble both rehearsing and performing:</p>

<ul>
<table>
	<tr>
		<td id="gallery">
			<a href="01.jpg" target="_blank"> <img src="01s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="02.jpg" target="_blank"> <img src="02s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="03.jpg" target="_blank"> <img src="03s.jpg" height="200" width="300"> </a>
		</td>
	</tr>


	<tr>
		<td id="gallery">
			<a href="04.jpg" target="_blank"> <img src="04s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="05.jpg" target="_blank"> <img src="05s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="06.jpg" target="_blank"> <img src="06s.jpg" height="200" width="300"> </a>
		</td>
	</tr>



	<tr>
		<td id="gallery">
			<a href="07.jpg" target="_blank"> <img src="07s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="08.jpg" target="_blank"> <img src="08s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="09.jpg" target="_blank"> <img src="09s.jpg" height="200" width="300"> </a>
		</td>
	</tr>


	<tr>
		<td id="gallery">
			<a href="10.JPG" target="_blank"> <img src="10s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="11.JPG" target="_blank"> <img src="11s.jpg" height="200" width="300"> </a>
		</td>

		<td id="gallery">
			<a href="12.JPG" target="_blank"> <img src="12s.jpg" height="200" width="300"> </a>
		</td>
    </tr>

    <tr>
		<td id="gallery">
			<a href="13.jpg" target="_blank"><img src="13s.jpg" height="200" width="300"></a>
		</td>

		<td id="gallery">
			<a href="14.jpg" target="_blank"><img src="14s.jpg" height="200" width="300"></a>
		</td>

		<td id="gallery">
			<a href="15.jpg" target="_blank"><img src="15s.jpg" height="95" width="300"></a>
		</td>
	</tr>


</table>
</ul>

<p>Our Spring 2014 concert can be viewed in HD in 3 parts: <br/><br/>
<ul><iframe width="1024" height="580" src="//www.youtube.com/embed/OL3V2dytb4Y" frameborder="0" allowfullscreen></iframe></ul><br/>
<ul><iframe width="1024" height="580" src="//www.youtube.com/embed/axxSrfTrCCg" frameborder="0" allowfullscreen></iframe></ul><br/>
<ul><iframe width="1024" height="580" src="//www.youtube.com/embed/_tSONSNQvDU" frameborder="0" allowfullscreen></iframe></ul><br/>
</p>

<?php include_once('footer.php'); ?>
