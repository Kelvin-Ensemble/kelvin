<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>History</title>

<h1>History of the Kelvin Ensemble</h1>

<table align="right">
	<tr>
		<td>
			<img src="../images/fb_cover1.jpg" alt="Rehearsing"; padding-left:10px; hspace="20"; align="right"/>
		</td>
	</tr>
	<br/>
	<tr>
		<td>
			<p style="text-align:right;"><i><span style="margin-right:15px">The orchestra rehearsing under Chris Swaffer in Bute Hall</span></i></p>
		</td>
	</tr>
</table>



<p>
	The Kelvin Ensemble was founded in 1991 by a group of students at <a href="http://www.gla.ac.uk" target="_new">Glasgow University</a>.
	This provided musicians from across the University with the opportunity to perform classical music concerts under the direction of professional conductors.

<p>
	In its first 10 years the Ensemble specialised in chamber music and was recognised as one of Scotland's leading non-professional chamber orchestras.
	Due to a size increase of over three times, the Ensemble now performs symphonic works rather than chamber music, but has continued to have the goal of allowing as many university students as possible the opportunity to perform orchestral music.

<p>
	The Ensemble's reputation has earned its musicians invitations to perform throughout the country, including representing Glasgow University in prestigious music festivals.
	The Ensemble's own concerts in the University's magnificent Bute Hall and Chapel regularly attracts large audiences.

<p>

	The Kelvin Ensemble is ideally placed to promote local and young talent, whether it is among its own members on in its choice of conductors and soloists.
	An impressive lineup of conductors has directed the Ensemble, including
		<a href="http://www.osj.org.uk/about-us/about-john-lubbock/" target="_new">John Lubbock</a>,
		<a href="http://www.nycos.co.uk/About-Us/Christopher-Bell" target="_new">Christopher Bell</a>,
		<a href="http://www.william-conway.com/" target="_new">Willam Conway</a>,
		<a href="http://www.boddice.fsnet.co.uk/" target="_new">Nigel Boddice</a>,
		<a href="http://www.ingpen.co.uk/artist/garry-walker/" target="_new">Garry Walker</a>,
		<a href="http://www.kennethwoods.net/" target="_new">Kenneth Woods</a>,
		<a href="http://www.aberdeenchamberorchestra.co.uk/Conductor.html" target="_new">Gareth John</a>,
		<a href="http://www.ollyandalex.com/" target="_new">Oliver Rundell</a>, and
		<a href="http://www.christopherswaffer.com/" target="_new">Chris Swaffer</a>.

<p>
	The Ensemble has also been the recipient of numerous awards in recognition of its pioneering work. These have included:
	<ul>
		<li>British Telecom/National Federation of Music Societies Innovation Award</li>
		<li>Enterprise in Higher Education Award</li>
		<li>National Heritage "Pairing Scheme" Award</li>
		<li>British Reserve Insurance Award</li>
	</ul>

The Ensemble has also produced four recordings:
	<ul>
		<li>"New Romantic Piano Music" by Callum Kenmuir (out of print)
		<li>Piano Concerto No. 1 by Erik Chisholm (out of print)
		<li><i>The Planets</i> by Gustav Holst
		<li>A Full Concert from 2011, includes Mendelssohn's <i>Fingal's Cave</i> and MacCunn's "The Land of the Mountain and the Flood"
	</ul>

	To celebrate the 10th Anniversary of the ensemble, a joint concert with the
	<a href="http://euco.eusa.ed.ac.uk/" target="_new">Edinburgh University Chamber Orchestra</a>
	was staged, with the combined orchestra performing Shostakovich's Symphony No. 5.

	The 20th Anniversary was celebrated by the Ensemble in February 2011. To mark the event Stravinsky's Greeting Prelude,
	a variation of "Happy Birthday," was performed. Former members of the Ensemble were invited to play during the concert,
	doubling the number of musicians for the performance of <i>The Planets Suite</i> by Holst.

<?php /*
<img src="Dec 2011 med.jpg" alt="Kelvin rehearsing in the Glasgow University Chapel" align="right">

<p>The Ensemble celebrated its tenth anniversary in 2001, which was marked by a hugely successful joint concert
with <a href="http://euco.eusa.ed.ac.uk/" target="_new">Edinburgh University Chamber Orchestra</a>, and in 2011
celebrated our 20th anniversary by performing the Planets Suite by Gustav Holst.  We now enjoy good links with
the <a href="http://www.gla.ac.uk/subjects/music/" target="_new">University Music Department</a> as well as
receiving generous support from other departments, and we are now looking at ways to improve these opportunities. In
2001 we were delighted that Sir and Lady Fraser agreed to become our Patrons.</p>


<p>This Season we have enjoyed and are looking forward to collaborations with Glasgow University Choral Society,
Edinburgh University Chamber Orchestra and Thomas Coats Memorial Choral Society. Due to the massive number of applications
to join the Ensemble this year, we are also looking at organising regular professional coaching sessions held within "Open Rehearsals".</p>


<p>All these features demonstrate that the Kelvin Ensemble is at the forefront of the amateur music community in Scotland. We hope to be able to welcome you to one of our concerts in the near future.</p>
*/
?>
<?php include_once('footer.php'); ?>
