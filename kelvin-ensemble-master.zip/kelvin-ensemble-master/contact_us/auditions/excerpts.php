<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>String Excerpts</title>

<h1>String Excerpts</h1>

<!--
<p>The excerpts for this year are not yet online, and will be put up closer to the audition time.</p>
-->

<p>All excerpts taken from Dvorak Symphony no. 7 and are to be prepared alongside a piece of your choice for your audition.</p>
<br/>
<p>Please prepare the section between the indicated red brackets.</p>
</br>
<p><b>Violins</b> - <a href="/contact_us/auditions/excerpts/violin.pdf">PDF</a></p>

<p><b>Violas</b> - <a href="/contact_us/auditions/excerpts/viola.pdf">PDF</a></p>

<p><b>Cellos</b> - <a href="/contact_us/auditions/excerpts/cello.pdf">PDF</a></p>

<p><b>Basses</b> - <a href="/contact_us/auditions/excerpts/bass.pdf">PDF</a></p>
<br/>

<p>Thank you and good luck!</p>

<?php include_once('footer.php'); ?>
