<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>String Auditions</title>

<h1>String Auditions</h1>

<p>The audition will consist of one prepared piece of your own choice, followed by an excerpt that <!--will be made available closer to the time--> is available <a href="/contact_us/auditions/excerpts.php">here</a>. You chosen piece should be approximately 5 minutes long - the panel may stop you after this time.</p>

<p>Weekend auditions will take place in the University Music Department, 14 University Gardens - just along from the Queen Margaret Union.</p>

<p>To book an audition please select a time below and complete the booking process. If you are having any difficulties, please contact <a href="mailto:webmaster&#64;kelvin-ensemble.co.uk">webmaster@kelvin-ensemble.co.uk</a>.

<br/><br/>
<iframe src="https://string-kelvin-ensemble-auditions.youcanbook.me/?noframe=true&skipHeaderFooter=true" style="width:100%;height:1000px;border:0px;background-color:transparent;" frameborder="0" allowtransparency="true" onload="keepInView(this);"></iframe>
<script>function keepInView(item) {if((document.documentElement&&document.documentElement.scrollTop)||document.body.scrollTop>item.offsetTop)item.scrollIntoView();}</script>

<p>Thank you and good luck!</p>

<?php include_once('footer.php'); ?>
