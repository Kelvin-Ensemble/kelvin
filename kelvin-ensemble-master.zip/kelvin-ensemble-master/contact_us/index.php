<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Contacts</title>

<h1>Contact Details</h1>
<p>
  The most appropriate addresses for a number of common queries are below.  The Ensemble also has a postbox in the University's Music Faculty.
</p>
  <ul>
    <li>For information on concerts, or to reserve tickets, please contact <a href="mailto:treasurer&#64;kelvin-ensemble.co.uk">treasurer&#64;kelvin-ensemble.co.uk</a></li>
    <li>To find out more about auditions and joining the ensemble, please contact <a href="mailto:stringmanager&#64;kelvin-ensemble.co.uk">stringmanager&#64;kelvin-ensemble.co.uk</a> for string players, or <a href="mailto:bwp&#64;kelvin-ensemble.co.uk">bwp&#64;kelvin-ensemble.co.uk</a> for brass, wind and percussion players.</li>
    <li>For information on our friends and sponsorship schemes, please contact <a href="mailto:friends&#64;kelvin-ensemble.co.uk">fundraising&#64;kelvin-ensemble.co.uk</a></li>
    <li>For other queries, please contact <a href="mailto:secretary&#64;kelvin-ensemble.co.uk">secretary&#64;kelvin-ensemble.co.uk</a> or <a href="mailto:webmaster&#64;kelvin-ensemble.co.uk">webmaster&#64;kelvin-ensemble.co.uk</a></li>
  </ul>

<?php include_once('footer.php'); ?>
