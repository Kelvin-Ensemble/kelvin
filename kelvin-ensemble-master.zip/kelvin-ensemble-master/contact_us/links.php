<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Links</title>

<h1>Useful Links</h1>


<h2>University of Glasgow</h2>
<ul>
  <li><a href="http://www.gla.ac.uk" target="_new">University Homepage</a></li>
  <li><a href="http://glasgowunimusicclub.weebly.com/" target="_new">Music Club</a></li>
  <li><a href="http://www.gla.ac.uk/events/musicintheuniversity/" target="_new">Music in the University</a></li>
  <li><a href="http://www.qmu.org.uk/" target="_new">Queen Margaret Union</a></li>
  <li><a href="http://www.guu.co.uk/" target="_new">Glasgow University Union</a></li>
  <li><a href="http://www.gla.ac.uk/schools/cca/" target="_new">School of Culture and Creative Arts</a></li>
  <li><a href="http://www.glasgowstudent.net/" target="_new">Students' Representative Council (SRC)</a></li>
</ul>

<h2>Other Orchestras</h2>
<ul>
  <li><a href="http://www.usso.org.uk/" target="_new">Universities of Scotland Symphony Orchestra (USSO)</a></li>
  <li><a href="http://euco.eusa.ed.ac.uk/" target="_new">Edinburgh University Chamber Orchestra</a></li>
  <li><a href="http://www.edinburghyouthorchestra.org.uk/" target="_new">Edinburgh Youth Orchestra</a></li>
  <li><a href="http://www.nyos.co.uk" target="_new">National Youth Orchestras of Scotland</a></li>
  <li><a href="http://www.sco.org.uk/" target="_new">Scottish Chamber Orchestra</a></li>
</ul>
<p>

  <?php include_once('footer.php'); ?>
