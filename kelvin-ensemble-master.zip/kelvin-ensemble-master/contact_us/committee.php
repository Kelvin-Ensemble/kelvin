<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Committee</title>

<h1>The committee for academic year 2016-17 is:</h1>
<ul>
  <table>
    <col width="25%">
    <col width="40%">
    <col width="35%">
      <tr>
        <td>Chairperson</td>
        <td>chairperson&#64;kelvin-ensemble.co.uk</td>
        <td>Samantha Julia Greenwood</td>
      </tr>
      <tr>
        <td>Secretary</td>
        <td>secretary&#64;kelvin-ensemble.co.uk</td>
        <td>Murdo Douglas</td>
      </tr>
      <tr>
        <td>Treasurer</td>
        <td>treasurer&#64;kelvin-ensemble.co.uk</td>
        <td>Arianna Clark</td>
      </tr>
      <tr>
        <td>Concert Manager</td>
        <td>concertorganiser&#64;kelvin-ensemble.co.uk</td>
        <td>Marie Driver</td>
      </tr>
      <tr>
        <td>Brass, Wind and Percussion Manager</td>
        <td>bwp&#64;kelvin-ensemble.co.uk</td>
        <td>Amy Fraser</td>
      </tr>
      <tr>
        <td>String Managers</td>
        <td>stringmanager&#64;kelvin-ensemble.co.uk</td>
        <td>Lina-Lotta Kauhanen and Ingrid Bols</td>
      </tr>
      <tr>
        <td>Librarian</td>
        <td>librarian&#64;kelvin-ensemble.co.uk</td>
        <td>Jack Findlay</td>
      </tr>
      <tr>
        <td>Social Managers</td>
        <td>socialmanager&#64;kelvin-ensemble.co.uk</td>
        <td>Barney Edmonds and Jamie Munro</td>
      </tr>
      <tr>
        <td>Publicist</td>
        <td>publicity&#64;kelvin-ensemble.co.uk</td>
        <td>Imogen Leadbetter</td>
      </tr>
      <tr>
        <td>Fundraising Co-ordinators</td>
        <td>fundraising&#64;kelvin-ensemble.co.uk</td>
        <td>Sagnick Mukherjee</td>
      </tr>
      <tr>
        <td>Webmaster</td>
        <td>webmaster&#64;kelvin-ensemble.co.uk</td>
        <td>Leah Spiedel Johnson</td>
      </tr>
<!--      <tr>
        <td>First Year Representative</td>
        <td>representative&#64;kelvin-ensemble.co.uk</td>
        <td>Andrew Macleod</td>
      </tr> -->
      <tr>
        <td>Ordinary Members</td>
        <td>ordinarymembers&#64;kelvin-ensemble.co.uk</td>
        <td>Malcolm Davers Millar, Sam Maya, Priannah Kajol Patel, Matthew Kennedy</td>
      </tr>
  </table>
</ul>

<?php include_once('footer.php'); ?>
