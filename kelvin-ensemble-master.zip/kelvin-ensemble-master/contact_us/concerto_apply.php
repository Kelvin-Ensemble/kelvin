<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Concerto Competition</title>

<h1>Concerto Competition</h1>

<br/>
<p>The Kelvin Ensemble are proud to present their annual Concerto Competition, which takes place on January 28th in Glasgow University Concert Hall.</p>
<p>Applications are invited from current or past members of the orchestra, along with any current students in Higher Education in Scotland.</p>
<p>The winner will perform their chosen piece with the orchestra in the 2017/18 academic year.</p>
<p>The application pack can be downloaded <a href="<?php echo BASE_URL;?>contact_us/concerto_comp_1617.pdf">here</a>.</p>
<p>Thank you and good luck! </p>

<br/>

<img src="<?php echo BASE_URL;?>images/concerto_nick.jpg" width="100%"/>
<p>Nick Lauener playing "Rhapsody in Blue" with the Kelvin Ensemble in March 2015</p>


<?php include_once('footer.php'); ?>
