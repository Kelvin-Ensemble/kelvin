<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Join</title>

<h1>Joining the Kelvin Ensemble</h1>

<br/>
<!--<p>
  Information on auditions coming soon</br>
</p>


<p>
  Kelvin Ensemble hold auditions shortly after term starts in September and October - Auditions are over for this year, but feel free to get in touch with us if you are interested in playing with us and we will let you know if we have a space for you.
</p>
-->

<p>
  String players can book an audition <a href="../contact_us/auditions/strings.php"><b>here</b></a> and Brass, Wind, Percussion and Piano can audition <a href="../contact_us/auditions/bwp.php"><b>here</b></a>.
</p>


<?php include_once('footer.php'); ?>
