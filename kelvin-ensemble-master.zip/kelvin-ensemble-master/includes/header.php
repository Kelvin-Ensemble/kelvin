<?php
include_once('base.php');
header("Content-type: text/html; charset=utf-8");
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
<link rel="stylesheet" title="body" media="screen" type="text/css" href="<?php echo BASE_URL;?>style.css" />
</head>

<center>
<body>

<?php include_once("analytics.php") ?>

<div id="page_container" href="<?php echo BASE_URL;?>">

<div id="title">
  <table>
    <tr>
      <td>
        <a href="<?php echo BASE_URL;?>"><img src="<?php echo BASE_URL;?>/images/Kelvin_Logo_Vector_White.png" alt="The Kelvin Ensemble" /></a>
      </td>
    <td><h1>&nbsp;</h1></td><td><h1>&nbsp;</h1></td>
      <td>
        <img src="<?php echo BASE_URL;?>/images/quote.png"/>
      </td>
    </tr>
  </table>
</div>


<div id="sidebar">
</div>

<div class="nav">
  <li>
      <a href="<?php echo BASE_URL;?>">Home</a>
    </li>

    <li>
        <a href="<?php echo BASE_URL;?>concerts/">Concerts &#9661;</a>
        <ul>
            <li><a href="<?php echo BASE_URL;?>concerts/">Upcoming Concerts</a></li>
            <li><a href="<?php echo BASE_URL;?>concerts/past_concerts_nav.php">Past Concerts</a></li>
        </ul>
    </li>

    <li id="about">
        <a href="<?php echo BASE_URL;?>about/">About &#9661;</a>
        <ul>
            <li><a href="<?php echo BASE_URL;?>about/">History</a></li>
            <li><a href="<?php echo BASE_URL;?>about/gallery/">Gallery</a></li>
            <li><a href="<?php echo BASE_URL;?>about/members.php">Members</a></li>
            <!--<li><a href="<?php echo BASE_URL;?>about/diary.php">Diary 2016</a></li>-->
        </ul>
    </li>

    <li>
        <a href="<?php echo BASE_URL;?>contact_us/">Contact Us &#9661;</a>
        <ul>
            <li><a href="<?php echo BASE_URL;?>contact_us/">Contacts</a></li>
            <li><a href="<?php echo BASE_URL;?>contact_us/join.php">Join</a></li>
            <li><a href="<?php echo BASE_URL;?>contact_us/committee.php">Committee</a></li>
            <li><a href="<?php echo BASE_URL;?>contact_us/links.php">Useful Links</a></li>
        </ul>
    </li>
    <li>
        <a href="<?php echo BASE_URL;?>support_us/">Support Us  &#9661;</a>
        <ul>
            <li><a href="<?php echo BASE_URL;?>support_us/mailing_list.php">Mailing List</a></li>
        </ul>
    </li>
    <!-- <li style="width: 100px;">
         <a href="https://kelvinensemble.wordpress.com/">Blog</a>
    </li> -->
</div>

<br/><br/><br/><br/><br/>
