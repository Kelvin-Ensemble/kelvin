<hr id="bottom_rule"/>

<div id="bottom_left">
<a href="http://www.facebook.com/kelvinensemble" target="_new"><img src="<?php echo BASE_URL;?>/images/facebook.png" height=30 width=30 alt="http://www.facebook.com/kelvinensemble" /></a>
<a href="https://twitter.com/#!/kelvinensemble/" target="_new"><img src="<?php echo BASE_URL;?>/images/twitter.png" height=30 width=30 alt="@kelvinensemble" /></a>
<a href="<?php echo BASE_URL;?>support_us/mailing_list.php"><img src="<?php echo BASE_URL;?>/images/mailchimp.png" height=30 width=30 alt="mailchimp"/></a>
<a href="https://www.easyfundraising.org.uk/causes/kelvinensemble/" target="_new"><img src="<?php echo BASE_URL;?>/images/easyfundraising.gif" alt="Easy Fundraising" /></a>
</div>

<b>
<div id="bottom_right">
&copy; Kelvin Ensemble <?php echo date("Y"); ?>
<br/>
Scottish Charity No: SC022303
<br/>
The Department of Music, University of Glasgow
<br/>
14 University Gardens, Glasgow, G12 8QQ
</div><br/>
</b>
<h3>&nbsp;</h3>

</div>
</center>
<br/>

</body>
</html>
