<?php ##base file for COST meeting website
define('BASE_PATH','/');
define('BASE_URL','http://'.$_SERVER['SERVER_NAME'].BASE_PATH);

?>
