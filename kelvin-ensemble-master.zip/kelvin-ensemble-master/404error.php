<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>404 Error</title>

404 error! Please navigate away using the above menus.

<?php include_once('footer.php'); ?>
