<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Thank You</title>

<p> Thank you for your generous donation to the Kelvin Ensemble.  You will shortly receive a confirmation from PayPal that we have received your payment.
</p>

<p>If you have qualified for discounted tickets (&#163;20-&#163;99.99 donation), and wish to purchase them through <a href="/concerts/">the site</a>, please use the "Concession Tickets" button.  If you qualify for free tickets, please e-mail the <a href="mailto:tickets@kelvin-ensemble.co.uk">Ticket Manager</a> to reserve them.
</p>

<p>If you have any questions or concerns, send an e-mail to the <a href="mailto:friends&#64;kelvin-ensemble.co.uk">Friends Manager</a>
</p>

<?php include_once('footer.php'); ?>
