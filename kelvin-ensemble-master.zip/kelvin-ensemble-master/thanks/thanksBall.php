<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Thank You</title>

<p> Thank you for purchasing tickets to our Ball.  You will shortly receive a confirmation from PayPal that we have received your payment.
</p>

<p>Your tickets will be available on the night of the Ball at the front door.
</p>

<p>If you have any questions or concerns, please send an e-mail to the <a href="mailto:socialmanager&#64;kelvin-ensemble.co.uk">Social Manager</a>
</p>

<?php include_once('footer.php'); ?>
