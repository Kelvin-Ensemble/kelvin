<?php
set_include_path(implode(PATH_SEPARATOR,Array('.','./includes','../includes','../../includes',get_include_path())));
include_once('header.php'); ?>

<title>Thank You</title>

<p> Thank you for purchasing tickets to our upcoming concert.  You will shortly receive a confirmation from PayPal that we have received your payment.
</p>

<p>Your tickets will be available on the night of the Concert at the front door.
</p>

<p>If you have any questions or concerns, send an e-mail to the <a href="mailto:tickets&#64;kelvin-ensemble.co.uk">Ticket Manager</a>
</p>

<?php include_once('footer.php'); ?>
